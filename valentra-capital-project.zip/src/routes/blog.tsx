import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

// /blog — SSR enabled (this is the only marketing route we render server-side
// per the brief). All other pages remain SSG-friendly.
export const Route = createFileRoute("/blog")({
  ssr: true,
  head: () => ({
    meta: [
      { title: "Insights & Blog — Valentra Capital" },
      { name: "description", content: "Operator-grade finance writing for UK SaaS founders." },
      { property: "og:title", content: "Insights & Blog — Valentra Capital" },
      { property: "og:description", content: "Operator-grade finance writing for UK SaaS founders." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="flex min-h-screen items-center justify-center px-6 pt-28">
        <div className="text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">Coming soon</span>
          <h1 className="mt-6 font-serif text-5xl text-white md:text-7xl">Insights</h1>
          <p className="mt-6 text-body/80">This page is being crafted. Check back shortly.</p>
        </div>
      </section>
    </SiteLayout>
  ),
});
