import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

// /cookies — placeholder for the cookie policy page.
export const Route = createFileRoute("/cookies")({
  head: () => ({
    meta: [
      { title: "Cookie Policy — Valentra Capital" },
      { name: "description", content: "How Valentra Capital uses cookies on this site." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <section className="flex min-h-screen items-center justify-center px-6 pt-28">
        <div className="text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">Coming soon</span>
          <h1 className="mt-6 font-serif text-5xl text-white md:text-7xl">Cookie Policy</h1>
          <p className="mt-6 text-body/80">This page is being crafted. Check back shortly.</p>
        </div>
      </section>
    </SiteLayout>
  ),
});
