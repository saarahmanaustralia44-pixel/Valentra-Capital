import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

/**
 * /about — founder story page.
 * Edit copy directly in the JSX. Arrays below drive the qualification
 * strip and values cards so you can add/remove items in one place.
 */

const qualifications = [
  "MSc Accounting & Finance — Sheffield Hallam, 2024",
  "CIMA Strategic Level — 11 exemptions (CSEP route)",
  "CA articleship — ICAI India",
  "FMVA in progress",
  "AFA Level 7 in progress",
];

const values: { title: string; body: string }[] = [
  {
    title: "Outcomes, not hours",
    body: "We quote fixed scope. You don't pay for our learning curve.",
  },
  {
    title: "AI-native, human-led",
    body: "AI does the grunt work. A qualified analyst signs off every number.",
  },
  {
    title: "Speak founder, not accountant",
    body: "No jargon. Every report written so a non-finance founder gets it in 30 seconds.",
  },
];

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Valentra Capital" },
      {
        name: "description",
        content:
          "Meet Saarah, founder of Valentra Capital. Chartered Accountant training, MSc Accounting & Finance, six years inside finance teams.",
      },
      { property: "og:title", content: "About Valentra Capital" },
      {
        property: "og:description",
        content: "Finance run by someone who's actually qualified.",
      },
    ],
    links: [{ rel: "canonical", href: "https://valentracapital.co.uk/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden px-6 pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="absolute inset-0 -z-10 hero-gradient" />
        <div className="mx-auto max-w-4xl text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">About</span>
          <h1 className="mt-6 font-serif text-5xl leading-[1.05] text-white md:text-7xl">
            Finance run by someone who's actually qualified.
          </h1>
          <p className="mt-6 text-lg text-body/80">
            Hi, I'm Saarah — founder of Valentra Capital.
          </p>
        </div>
      </section>

      {/* ============ TWO-COLUMN STORY ============ */}
      <section className="bg-navy-elevated px-6 py-20 md:py-28">
        <div className="mx-auto grid max-w-6xl items-start gap-12 md:grid-cols-[minmax(0,1fr)_1.4fr] md:gap-16">
          {/* Portrait placeholder — replace src with real photo when ready */}
          <div className="mx-auto w-full max-w-sm">
            <div className="relative aspect-[3/4] overflow-hidden rounded-xl border-2 border-gold/70 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.6)]">
              <div className="absolute inset-0 bg-gradient-to-br from-[oklch(0.28_0.04_255)] via-[oklch(0.22_0.03_255)] to-[oklch(0.16_0.03_255)]" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span
                  aria-label="Portrait of Saarah placeholder"
                  role="img"
                  className="font-serif text-7xl text-gold/50"
                >
                  S
                </span>
              </div>
            </div>
            <p className="mt-4 text-center text-xs uppercase tracking-[0.22em] text-caption">
              Saarah · Founder
            </p>
          </div>

          {/* Body copy — 3 paragraphs */}
          <div className="space-y-6 text-lg leading-relaxed text-body/85">
            <p>
              I've spent the last six years inside finance teams — management accounting, FP&amp;A,
              building dashboards in Power BI, automating reporting in n8n. I trained as a
              Chartered Accountant in India before completing my MSc in Accounting and Finance at
              Sheffield Hallam in 2024.
            </p>
            <p>
              Traditional accountants spend their time on the past. I built Valentra because
              founders need finance that looks forward — forecasts that catch problems before they
              bite, dashboards investors actually read, and automation that gives you back the 12
              hours a week you're currently losing to spreadsheets.
            </p>
            <p>
              Valentra combines proper qualified finance work with AI and automation. That's why
              a single fractional analyst can deliver what used to need a three-person finance
              team.
            </p>
          </div>
        </div>
      </section>

      {/* ============ QUALIFICATIONS STRIP ============ */}
      <section className="px-6 py-20 md:py-24">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <span className="text-xs uppercase tracking-[0.28em] text-gold">Credentials</span>
            <h2 className="mt-4 font-serif text-3xl text-white md:text-4xl">
              Properly qualified, properly trained
            </h2>
          </div>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {qualifications.map((q) => (
              <div
                key={q}
                className="rounded-xl border border-gold/40 bg-navy-elevated p-5 text-sm leading-relaxed text-body/90 transition hover:border-gold hover:-translate-y-0.5"
              >
                {q}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ VALUES ============ */}
      <section className="bg-navy-elevated px-6 py-20 md:py-28">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <span className="text-xs uppercase tracking-[0.28em] text-gold">How we work</span>
            <h2 className="mt-4 font-serif text-3xl text-white md:text-4xl">Our values</h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {values.map((v) => (
              <div
                key={v.title}
                className="group rounded-xl border border-border bg-[oklch(0.20_0.03_255)] p-8 transition hover:border-gold/50"
              >
                <h3 className="font-serif text-xl text-gold">{v.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-body/80">{v.body}</p>
                <div className="mt-6 h-px gold-divider opacity-60 transition-opacity group-hover:opacity-100" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CLOSING CTA ============ */}
      <section className="px-6 pb-28 pt-20">
        <div className="mx-auto max-w-3xl rounded-2xl border border-gold/30 bg-navy-elevated px-8 py-14 text-center">
          <h3 className="font-serif text-2xl text-white md:text-3xl">
            Want to talk finance with someone who actually gets it?
          </h3>
          <Link
            to="/contact"
            className="mt-8 inline-flex items-center rounded-md bg-gold px-8 py-3.5 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft"
          >
            Book a clarity call →
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
