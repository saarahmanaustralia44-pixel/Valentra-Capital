import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

/**
 * /services — full services page.
 * Three tiers (Monthly Retainer, Annual Compliance, Consulting & Structuring),
 * each rendered from a typed array so you can edit copy/prices in one place.
 *
 * To edit a card: change the object in the relevant array below.
 * To add/remove a card: add/remove an object in the array.
 * JSON-LD schema at the bottom is auto-built from the same arrays.
 */

type ServiceCard = {
  name: string;
  unit: string;          // e.g. "Per quarter", "Monthly pack"
  description: string;   // what's included
  client: string;        // typical client
  price: string;         // displayed price (with * footnote marker)
};

// SECTION 1 — Monthly Retainer
const monthlyRetainer: ServiceCard[] = [
  {
    name: "Bookkeeping — Starter",
    unit: "Up to 50 txn/month",
    description:
      "Bank rec, expense coding, monthly P&L. Cloud setup on Xero or QuickBooks included.",
    client: "Sole trader / micro",
    price: "£75–150/month*",
  },
  {
    name: "Bookkeeping — Growth",
    unit: "Up to 150 txn/month",
    description:
      "Full reconciliation, categorised accounts, monthly reporting pack with commentary.",
    client: "Small Ltd",
    price: "£150–275/month*",
  },
  {
    name: "Payroll",
    unit: "Per payroll run",
    description:
      "Payslips, RTI submissions, PAYE compliance, workplace pension.",
    client: "1–5 employees",
    price: "£45–85/month*",
  },
  {
    name: "VAT Returns",
    unit: "Per quarter",
    description: "MTD-compliant HMRC submission. Standard or flat-rate.",
    client: "VAT-registered",
    price: "£60–120/quarter*",
  },
  {
    name: "Management Accounts",
    unit: "Monthly pack",
    description:
      "P&L, balance sheet, cashflow, budget vs actual variance.",
    client: "Growing SME",
    price: "£150–250/month*",
  },
];

// SECTION 2 — Annual Compliance
const annualCompliance: ServiceCard[] = [
  {
    name: "Year-End Accounts",
    unit: "Annual",
    description:
      "Statutory accounts + CT600 + Companies House filing.",
    client: "Small Ltd <£300k turnover",
    price: "£400–750*",
  },
  {
    name: "Self-Assessment (SA100)",
    unit: "Annual",
    description:
      "Director salary, dividends, rental or employment income. HMRC submission.",
    client: "Director / sole trader",
    price: "£120–250*",
  },
  {
    name: "Corporation Tax Return (CT600 standalone)",
    unit: "Annual",
    description:
      "CT calculation and HMRC e-filing where YE accounts handled elsewhere.",
    client: "Small Ltd",
    price: "£175–350*",
  },
  {
    name: "Confirmation Statement",
    unit: "Annual",
    description: "Annual Companies House filing.",
    client: "All Ltd companies",
    price: "£35–65*",
  },
];

// SECTION 3 — Consulting & Structuring
const consulting: ServiceCard[] = [
  {
    name: "Business Structuring Advisory",
    unit: "One-off engagement",
    description:
      "Sole trader → Ltd / partnership review. Tax efficiency, ownership, HMRC implications, written report.",
    client: "Founder incorporating",
    price: "£275–550*",
  },
  {
    name: "Profit Extraction Strategy",
    unit: "One-off engagement",
    description:
      "Salary vs dividends modelling. NI/IT optimisation, pension options.",
    client: "Ltd director",
    price: "£200–400*",
  },
  {
    name: "FP&A Engagement",
    unit: "Project",
    description:
      "Annual budget, 12-month cashflow forecast, variance framework, Power BI dashboard setup.",
    client: "Growing SME",
    price: "£500–1,200*",
  },
  {
    name: "Financial Health Review",
    unit: "One-off",
    description:
      "Books review, reporting gap analysis, metrics assessment, prioritised action plan.",
    client: "New client",
    price: "£175–325*",
  },
  {
    name: "Cloud Migration",
    unit: "Project",
    description:
      "Xero / QuickBooks / FreeAgent setup, chart of accounts, data import, training.",
    client: "Moving off spreadsheets",
    price: "£250–500*",
  },
];

// Build a single JSON-LD Service entry from a card.
const buildServiceLd = (s: ServiceCard) => ({
  "@context": "https://schema.org",
  "@type": "Service",
  name: s.name,
  description: s.description,
  serviceType: "Accounting and Financial Consulting",
  areaServed: { "@type": "Country", name: "United Kingdom" },
  provider: {
    "@type": "Organization",
    name: "Valentra Capital Accounting and Consulting Limited",
    url: "https://valentracapital.co.uk",
  },
  audience: { "@type": "Audience", audienceType: s.client },
  offers: {
    "@type": "Offer",
    priceCurrency: "GBP",
    priceSpecification: { "@type": "PriceSpecification", price: s.price },
  },
});

const allServices = [...monthlyRetainer, ...annualCompliance, ...consulting];

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Valentra Capital" },
      {
        name: "description",
        content:
          "Bookkeeping, payroll, VAT, year-end accounts, FP&A and structuring for UK SaaS founders and scaling SMEs.",
      },
      { property: "og:title", content: "Services — Valentra Capital" },
      {
        property: "og:description",
        content:
          "Three tiers: monthly retainer, annual compliance, consulting & structuring. Transparent pricing.",
      },
    ],
    links: [{ rel: "canonical", href: "https://valentracapital.co.uk/services" }],
    // One JSON-LD <script> per service for SEO (14 in total).
    scripts: allServices.map((s) => ({
      type: "application/ld+json",
      children: JSON.stringify(buildServiceLd(s)),
    })),
  }),
  component: ServicesPage,
});

// ---------- Card component ----------
function ServiceTile({ card }: { card: ServiceCard }) {
  return (
    <article
      className="group flex h-full flex-col rounded-2xl border border-gold/20 bg-navy-elevated p-7 transition-all duration-200 hover:-translate-y-px hover:border-gold/60 hover:shadow-[0_10px_40px_-20px_rgba(201,169,97,0.35)]"
    >
      <div className="text-[11px] uppercase tracking-[0.2em] text-gold/80">{card.unit}</div>
      <h3 className="mt-3 font-serif text-[22px] leading-snug text-gold">{card.name}</h3>
      <p className="mt-4 text-sm leading-relaxed text-white/85">{card.description}</p>
      <p className="mt-4 text-xs italic text-caption">Typical client: {card.client}</p>
      <div className="mt-auto pt-6 text-right font-sans text-2xl font-bold text-gold">
        {card.price}
      </div>
    </article>
  );
}

// ---------- Tier section ----------
function TierSection({
  eyebrow,
  title,
  intro,
  cards,
}: {
  eyebrow: string;
  title: string;
  intro: string;
  cards: ServiceCard[];
}) {
  return (
    <section className="px-6 py-20">
      <div className="mx-auto max-w-7xl">
        <div className="max-w-3xl">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">{eyebrow}</span>
          <h2 className="mt-4 font-serif text-3xl text-gold md:text-4xl">{title}</h2>
          <p className="mt-4 text-base text-body/80">{intro}</p>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c) => (
            <ServiceTile key={c.name} card={c} />
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------- Page ----------
function ServicesPage() {
  return (
    <SiteLayout>
      {/* HEADER */}
      <section className="px-6 pt-32 pb-10">
        <div className="mx-auto max-w-5xl text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">Our Services</span>
          <h1 className="mt-6 font-serif text-5xl text-white md:text-7xl">
            Services that <span className="italic text-gold">scale with you</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-body/80">
            From your first set of books to investor-ready board packs — choose the level that fits your stage.
          </p>
        </div>
      </section>

      {/* SECTION 1 */}
      <TierSection
        eyebrow="Tier 01 · Ongoing"
        title="Monthly Retainer"
        intro="Continuous bookkeeping, compliance and reporting. AML onboarding required before service begins."
        cards={monthlyRetainer}
      />

      {/* BUNDLE BANNER */}
      <section className="border-y border-gold/15 bg-[#0B1322] px-6 py-16">
        <div className="mx-auto max-w-5xl text-center">
          <h3 className="font-serif text-3xl text-gold md:text-4xl">Bundle and save</h3>
          <p className="mx-auto mt-5 max-w-3xl text-body/85">
            Bookkeeping + payroll + VAT + management accounts → single preferential monthly retainer.
            Year-end + CT600 + confirmation statement + director self-assessment → single annual fee.
            Contact us for a combined quote.
          </p>
          <Link
            to="/contact"
            className="mt-7 inline-flex items-center rounded-md border border-gold/60 px-5 py-2.5 text-sm font-medium text-gold transition hover:bg-gold/10"
          >
            Request a combined quote →
          </Link>
        </div>
      </section>

      {/* SECTION 2 */}
      <TierSection
        eyebrow="Tier 02 · Annual"
        title="Annual Compliance"
        intro="Statutory filings and tax returns delivered on time, every time."
        cards={annualCompliance}
      />

      {/* SECTION 3 */}
      <TierSection
        eyebrow="Tier 03 · Bespoke"
        title="Consulting & Structuring"
        intro="Strategic advisory, FP&A and system implementation for founders making structural decisions."
        cards={consulting}
      />

      {/* FOOTNOTES */}
      <section className="px-6 pb-10">
        <div className="mx-auto max-w-4xl rounded-xl border border-border bg-navy-elevated/60 p-6">
          <ul className="space-y-2 text-xs italic text-caption">
            <li>— All fees exclude VAT.</li>
            <li>
              — *Prices vary based on volume, complexity and current condition of your books. Final fee confirmed after free 15-min discovery call.
            </li>
            <li>
              — All new clients complete AML onboarding and sign an engagement letter before service begins. Upfront payment required.
            </li>
          </ul>
        </div>
      </section>

      {/* CLOSING CTA */}
      <section className="px-6 pb-28 pt-10">
        <div className="mx-auto max-w-3xl text-center">
          <p className="font-serif text-2xl text-white md:text-3xl">
            Not sure which fits?
          </p>
          <Link
            to="/contact"
            className="mt-6 inline-flex items-center rounded-md bg-gold px-6 py-3 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft"
          >
            Book your free 15-minute clarity call →
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
