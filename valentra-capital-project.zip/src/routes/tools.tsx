import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";

/**
 * /tools — Valentra Investor Finance Suite product showcase.
 *
 * Edit a product: change the object in `products` or `freeTools`.
 * Each paid product card renders a 16:9 screenshot placeholder, name, blurb,
 * price, and Payhip "Buy now" button. The bundle card uses `featured: true`
 * to get a gold border and "Best value" ribbon.
 */

type Product = {
  name: string;
  description: string;
  price: string;
  href: string;        // Payhip checkout URL — swap when ready
  featured?: boolean;  // true → gold border + ribbon
};

// Five paid AI tools + one bundle
const products: Product[] = [
  {
    name: "VC Stress Test",
    description: "Score your investor readiness out of 100 in under 5 minutes.",
    price: "£49",
    href: "https://payhip.com/valentracapital",
  },
  {
    name: "Revenue Quality Score",
    description: "Identify revenue concentration, churn and retention risks.",
    price: "£29",
    href: "https://payhip.com/valentracapital",
  },
  {
    name: "Investor Objection Simulator",
    description: "Practise answering tough VC questions before the real meeting.",
    price: "£39",
    href: "https://payhip.com/valentracapital",
  },
  {
    name: "CFO Letter Generator",
    description: "Monthly board-ready CFO letters in minutes.",
    price: "£29/month",
    href: "https://payhip.com/valentracapital",
  },
  {
    name: "Board Pack Narrative Builder",
    description: "Turn raw P&L into a board-ready narrative.",
    price: "£39",
    href: "https://payhip.com/valentracapital",
  },
  {
    name: "Investor Finance Suite — Bundle",
    description: "All 5 tools, lifetime access.",
    price: "£149",
    href: "https://payhip.com/valentracapital",
    featured: true,
  },
];

// Free / lead-magnet tools — smaller card row
const freeTools: { name: string; price: string; href: string }[] = [
  { name: "VAT and Tax Calculator", price: "Free", href: "/contact" },
  { name: "SaaS Financial Model UK", price: "£34.99", href: "https://payhip.com/valentracapital" },
  { name: "Business Health Score", price: "£14.99", href: "https://payhip.com/valentracapital" },
];

export const Route = createFileRoute("/tools")({
  head: () => ({
    meta: [
      { title: "Tools — Valentra Investor Finance Suite" },
      {
        name: "description",
        content:
          "AI-powered finance tools for founders. Self-serve diagnostics built on Claude AI — investor readiness, revenue quality, board packs and more.",
      },
      { property: "og:title", content: "Valentra Investor Finance Suite" },
      {
        property: "og:description",
        content: "Self-serve AI finance tools for founders. No spreadsheet skills required.",
      },
    ],
    links: [{ rel: "canonical", href: "https://valentracapital.co.uk/tools" }],
  }),
  component: ToolsPage,
});

function ToolsPage() {
  return (
    <SiteLayout>
      {/* ============ HEADER ============ */}
      <section className="relative overflow-hidden px-6 pt-32 pb-16 md:pt-40 md:pb-24">
        <div className="absolute inset-0 -z-10 hero-gradient" />
        <div className="mx-auto max-w-5xl text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">
            Investor Finance Suite
          </span>
          <h1 className="mt-6 font-serif text-5xl leading-[1.05] text-white md:text-7xl">
            AI-powered finance tools,
            <br />
            built for founders.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-body/80">
            Self-serve diagnostic tools. Built on Claude AI. No spreadsheet skills required.
          </p>
        </div>
      </section>

      {/* ============ PRODUCT GRID ============ */}
      <section className="bg-navy-elevated px-6 py-20 md:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {products.map((p) => (
              <ProductCard key={p.name} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* ============ FREE TOOLS & LEAD MAGNETS ============ */}
      <section className="px-6 py-20 md:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <h2 className="font-serif text-3xl text-gold md:text-4xl">
              Free tools and lead magnets
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-body/75">
              Quick-win calculators and templates to get you started.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {freeTools.map((t) => (
              <a
                key={t.name}
                href={t.href}
                target={t.href.startsWith("http") ? "_blank" : undefined}
                rel={t.href.startsWith("http") ? "noreferrer" : undefined}
                className="group flex items-center justify-between rounded-xl border border-border bg-navy-elevated p-6 transition hover:border-gold/60"
              >
                <div>
                  <div className="font-serif text-lg text-white group-hover:text-gold transition-colors">
                    {t.name}
                  </div>
                  <div className="mt-1 text-xs uppercase tracking-[0.2em] text-caption">
                    {t.price}
                  </div>
                </div>
                <span className="text-gold transition-transform group-hover:translate-x-1">→</span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CLOSING CTA ============ */}
      <section className="px-6 pb-28">
        <div className="mx-auto max-w-3xl rounded-2xl border border-gold/30 bg-navy-elevated px-8 py-14 text-center">
          <h3 className="font-serif text-2xl text-white md:text-3xl">
            Want a custom tool built for your business?
          </h3>
          <Link
            to="/contact"
            className="mt-8 inline-flex items-center rounded-md bg-gold px-8 py-3.5 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft"
          >
            Book a call →
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}

/* ============ PRODUCT CARD ============
 * 16:9 screenshot placeholder on top, then name, blurb,
 * price tag (bottom-left), and Buy now button (bottom-right).
 * `featured` adds gold border + "Best value" ribbon.
 */
function ProductCard({ product }: { product: Product }) {
  const { name, description, price, href, featured } = product;
  return (
    <div
      className={`relative flex flex-col overflow-hidden rounded-xl border bg-[oklch(0.20_0.03_255)] transition hover:-translate-y-1 ${
        featured
          ? "border-gold shadow-[0_0_0_1px_var(--color-gold)] ring-1 ring-gold/30"
          : "border-border hover:border-gold/40"
      }`}
    >
      {featured && (
        <div className="absolute right-4 top-4 z-10 rounded-full bg-gold px-3 py-1 text-[10px] font-medium uppercase tracking-[0.18em] text-primary-foreground">
          Best value
        </div>
      )}

      {/* 16:9 screenshot placeholder — replace with <img src="..." alt={name + " screenshot"} /> */}
      <div
        role="img"
        aria-label={`${name} screenshot placeholder`}
        className="relative aspect-[16/9] w-full overflow-hidden border-b border-border bg-gradient-to-br from-[oklch(0.25_0.04_255)] via-[oklch(0.22_0.03_255)] to-[oklch(0.18_0.03_255)]"
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-serif text-3xl text-gold/40">V</span>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-px gold-divider" />
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-serif text-xl text-gold">{name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-body/80">{description}</p>

        <div className="mt-6 flex items-center justify-between">
          <span className="text-xs uppercase tracking-[0.2em] text-caption">
            <span className="text-lg font-semibold text-white tracking-normal normal-case">
              {price}
            </span>
          </span>
          <a
            href={href}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center rounded-md bg-gold px-4 py-2 text-xs font-medium text-primary-foreground transition hover:bg-gold-soft"
          >
            Buy now →
          </a>
        </div>
      </div>
    </div>
  );
}
