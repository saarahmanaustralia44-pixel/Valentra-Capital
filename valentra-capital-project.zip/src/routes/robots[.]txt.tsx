import { createFileRoute } from "@tanstack/react-router";

// robots.txt — allow everything, point crawlers at the sitemap.
export const Route = createFileRoute("/robots.txt")({
  server: {
    handlers: {
      GET: async () => {
        const body = `User-agent: *
Allow: /

Sitemap: https://valentracapital.co.uk/sitemap.xml
`;
        return new Response(body, {
          headers: { "Content-Type": "text/plain; charset=utf-8" },
        });
      },
    },
  },
});
