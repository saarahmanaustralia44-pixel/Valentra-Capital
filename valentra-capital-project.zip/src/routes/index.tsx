import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/Layout";
import { FileSpreadsheet, MessagesSquare, Clock } from "lucide-react";

/* ============================================================
   HOME (/) — Valentra Capital
   Six sections in order: Hero · Trust Strip · Problem · Solution
   · Results · Final CTA. Edit each component below; they're kept
   local to this file so a single edit pass touches one place.
   JSON-LD Organisation schema is attached via head().
   ============================================================ */

const organisationJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Valentra Capital Accounting and Consulting Limited",
  legalName: "Valentra Capital Accounting and Consulting Limited",
  url: "https://valentracapital.co.uk",
  email: "info@valentracapital.co.uk",
  telephone: "+44 7398 909701",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Gresley House, Ten Pound Walk",
    addressLocality: "Doncaster",
    postalCode: "DN4 5HX",
    addressCountry: "GB",
  },
  identifier: "Company No: 16829883",
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Valentra Capital — AI-native finance for SaaS founders" },
      {
        name: "description",
        content:
          "We install a finance function for early-stage SaaS companies in 30 days. Board-ready reporting, variance alerts, live revenue dashboards — without hiring a CFO.",
      },
      { property: "og:title", content: "Valentra Capital — AI-native finance for SaaS founders" },
      {
        property: "og:description",
        content: "From messy spreadsheets to board-ready reporting in 30 days. Guaranteed.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://valentracapital.co.uk/" },
    ],
    links: [{ rel: "canonical", href: "https://valentracapital.co.uk/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(organisationJsonLd),
      },
    ],
  }),
  component: HomePage,
});

/* ---------- HERO ---------------------------------------------
   Full-viewport hero. Background is a layered gradient + subtle
   gold particle field (pure CSS, no JS) for a fintech feel.
   ------------------------------------------------------------- */
function GoldParticles() {
  // Tiny decorative dots — pointer-events-none so they never block interaction.
  // Adjust count by editing this array; positions are random-ish but stable.
  const dots = [
    { top: "12%", left: "8%", size: 3, delay: "0s" },
    { top: "22%", left: "78%", size: 2, delay: "1.2s" },
    { top: "38%", left: "18%", size: 4, delay: "2.4s" },
    { top: "55%", left: "65%", size: 2, delay: "0.6s" },
    { top: "68%", left: "30%", size: 3, delay: "3s" },
    { top: "78%", left: "82%", size: 2, delay: "1.8s" },
    { top: "32%", left: "48%", size: 2, delay: "2.1s" },
    { top: "82%", left: "12%", size: 3, delay: "0.9s" },
    { top: "16%", left: "55%", size: 2, delay: "3.6s" },
    { top: "48%", left: "92%", size: 3, delay: "1.5s" },
  ];
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {dots.map((d, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-gold/60 animate-float-slow"
          style={{
            top: d.top,
            left: d.left,
            width: d.size,
            height: d.size,
            animationDelay: d.delay,
            boxShadow: "0 0 8px oklch(0.76 0.10 85 / 0.6)",
          }}
        />
      ))}
    </div>
  );
}

function Hero() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden hero-gradient pt-28">
      <div className="absolute inset-0 grid-pattern" aria-hidden />
      <GoldParticles />
      {/* Soft colour washes for depth */}
      <div aria-hidden className="absolute -left-32 top-1/3 h-80 w-80 rounded-full bg-gold/10 blur-3xl animate-float-slow" />
      <div
        aria-hidden
        className="absolute -right-24 bottom-10 h-96 w-96 rounded-full bg-teal/15 blur-3xl animate-float-slow"
        style={{ animationDelay: "2s" }}
      />

      <div className="relative mx-auto max-w-5xl px-6 text-center">
        <div className="inline-flex items-center gap-3">
          <span className="h-px w-8 bg-gold" />
          <span className="text-xs font-medium uppercase tracking-[0.28em] text-gold">
            AI-Native Finance for Founders
          </span>
          <span className="h-px w-8 bg-gold" />
        </div>

        {/* H1: 64px desktop / 40px mobile, Playfair Display */}
        <h1 className="mt-8 font-serif text-[40px] leading-[1.08] text-white md:text-[64px]">
          We install a finance function for early-stage SaaS companies
          <span className="block italic text-gold">— in 30 days. Guaranteed.</span>
        </h1>

        <p className="mx-auto mt-8 max-w-2xl text-base leading-relaxed text-body/85 md:text-xl">
          From messy spreadsheets to board-ready reporting, automated variance
          alerts, and live revenue dashboards. Without hiring a full-time CFO.
        </p>

        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
          <Link
            to="/contact"
            className="inline-flex items-center justify-center rounded-md bg-gold px-7 py-3.5 text-sm font-medium text-primary-foreground shadow-[0_10px_40px_-15px_oklch(0.76_0.10_85/0.6)] transition hover:bg-gold-soft"
          >
            Book your free 15-min clarity call
          </Link>
          <Link
            to="/tools"
            className="inline-flex items-center justify-center rounded-md border border-gold/50 px-7 py-3.5 text-sm font-medium text-gold transition hover:bg-gold/10"
          >
            Browse our tools
          </Link>
        </div>
      </div>
    </section>
  );
}

/* ---------- TRUST STRIP --------------------------------------
   Five placeholder logo blocks. Swap each <div> for a real
   <img loading="lazy" alt="Client name" src="..." /> later.
   ------------------------------------------------------------- */
function TrustStrip() {
  return (
    <section className="border-y border-border bg-navy py-14">
      <div className="mx-auto max-w-7xl px-6 text-center">
        <p className="text-xs uppercase tracking-[0.25em] text-caption">
          Trusted by founders building the next generation of UK SaaS
        </p>
        <div className="mt-8 grid grid-cols-2 items-center gap-8 sm:grid-cols-3 md:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="mx-auto h-9 w-32 rounded bg-white/5 border border-white/5"
              aria-label="Client logo placeholder"
              role="img"
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- PROBLEM ------------------------------------------
   Three pain-point cards with a lucide icon, headline, and body.
   Hover: subtle gold border to telegraph interactivity.
   ------------------------------------------------------------- */
function Problem() {
  const items = [
    {
      Icon: FileSpreadsheet,
      title: "Finances scattered across 14 spreadsheets",
      copy: "Versions, broken formulas, no single source of truth — and no time to fix it.",
    },
    {
      Icon: MessagesSquare,
      title: "Investors keep asking for numbers you don't have",
      copy: "MRR cohorts, burn multiple, runway scenarios. You're rebuilding the deck every month.",
    },
    {
      Icon: Clock,
      title: "12 hours a week lost to bookkeeping",
      copy: "Founder time on reconciliations is the most expensive line in your P&L.",
    },
  ];
  return (
    <section className="bg-navy-elevated py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl">
          <span className="text-xs uppercase tracking-[0.25em] text-gold">The Problem</span>
          <h2 className="mt-4 font-serif text-3xl text-white md:text-5xl">
            You didn't start a company to{" "}
            <span className="italic text-gold">manage spreadsheets.</span>
          </h2>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {items.map(({ Icon, title, copy }) => (
            <div
              key={title}
              className="group relative overflow-hidden rounded-xl border border-border bg-navy p-8 transition hover:border-gold/50"
            >
              <Icon className="h-8 w-8 text-gold" aria-hidden strokeWidth={1.5} />
              <h3 className="mt-6 font-serif text-xl text-white">{title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-body/80">{copy}</p>
              <div className="absolute inset-x-0 bottom-0 h-px gold-divider opacity-0 transition group-hover:opacity-100" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- SOLUTION -----------------------------------------
   Three service-tier preview cards. Each links to /services.
   Edit pricing / copy here OR in the Services route to keep
   them aligned.
   ------------------------------------------------------------- */
function Solution() {
  const tiers = [
    {
      title: "Monthly Retainer",
      price: "From £75/month",
      copy: "Bookkeeping, payroll, VAT, management accounts.",
    },
    {
      title: "Annual Compliance",
      price: "From £35",
      copy: "Year-end accounts, CT600, self-assessment, confirmation statements.",
    },
    {
      title: "Consulting & FP&A",
      price: "From £175",
      copy: "Structuring, profit extraction, FP&A engagements, cloud migration.",
    },
  ];
  return (
    <section className="bg-navy py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs uppercase tracking-[0.25em] text-gold">The Solution</span>
          <h2 className="mt-4 font-serif text-3xl text-white md:text-5xl">
            One operating system for your finance function.
          </h2>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {tiers.map((t) => (
            <div
              key={t.title}
              className="group relative flex flex-col rounded-2xl border border-border bg-navy-elevated p-8 transition hover:border-gold/50"
            >
              <div className="text-xs uppercase tracking-[0.22em] text-gold">{t.price}</div>
              <h3 className="mt-4 font-serif text-2xl text-white md:text-3xl">{t.title}</h3>
              <p className="mt-4 text-sm leading-relaxed text-body/85">{t.copy}</p>
              <Link
                to="/services"
                className="mt-8 inline-flex items-center gap-2 text-sm font-medium text-gold gold-underline"
              >
                Explore <span aria-hidden>→</span>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- RESULTS / STATS ----------------------------------
   Three big gold numbers with small white labels.
   ------------------------------------------------------------- */
function Results() {
  const stats = [
    { v: "30 days", l: "to a live revenue dashboard" },
    { v: "100%", l: "MTD-compliant submissions" },
    { v: "60%", l: "average reduction in month-end close time" },
  ];
  return (
    <section className="relative overflow-hidden bg-navy py-28">
      <div aria-hidden className="absolute inset-x-0 top-1/2 h-px gold-divider opacity-30" />
      <div className="mx-auto max-w-5xl px-6 text-center">
        <span className="text-xs uppercase tracking-[0.25em] text-gold">Results</span>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {stats.map((s) => (
            <div key={s.l} className="rounded-xl border border-border bg-navy-elevated p-10">
              <div className="font-serif text-5xl text-gold md:text-6xl">{s.v}</div>
              <div className="mt-4 text-xs uppercase tracking-[0.2em] text-white/90">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- FINAL CTA ---------------------------------------- */
function FinalCTA() {
  return (
    <section className="bg-navy px-6 py-24">
      <div className="mx-auto max-w-5xl rounded-2xl border border-gold/50 bg-navy-elevated p-12 text-center md:p-20">
        <h2 className="font-serif text-3xl text-white md:text-5xl">
          Ready to install your <span className="italic text-gold">finance function?</span>
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-body/85">
          Free 15-minute clarity call. No sales pitch. Walk away with at least one
          actionable insight.
        </p>
        <Link
          to="/contact"
          className="mt-10 inline-flex items-center justify-center rounded-md bg-gold px-8 py-4 text-sm font-medium text-primary-foreground shadow-[0_15px_50px_-15px_oklch(0.76_0.10_85/0.7)] transition hover:bg-gold-soft"
        >
          Book my clarity call →
        </Link>
      </div>
    </section>
  );
}

function HomePage() {
  return (
    <SiteLayout>
      <Hero />
      <TrustStrip />
      <Problem />
      <Solution />
      <Results />
      <FinalCTA />
    </SiteLayout>
  );
}
