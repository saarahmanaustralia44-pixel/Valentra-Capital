import { createFileRoute } from "@tanstack/react-router";

// Static sitemap. Edit BASE_URL once a custom domain is wired up.
const BASE_URL = "https://valentracapital.co.uk";
const ROUTES = [
  "/",
  "/services",
  "/tools",
  "/about",
  "/case-studies",
  "/contact",
  "/blog",
  "/privacy",
  "/cookies",
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const today = new Date().toISOString().slice(0, 10);
        const urls = ROUTES.map(
          (p) =>
            `  <url><loc>${BASE_URL}${p}</loc><lastmod>${today}</lastmod><changefreq>weekly</changefreq></url>`,
        ).join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>`;
        return new Response(xml, {
          headers: { "Content-Type": "application/xml; charset=utf-8" },
        });
      },
    },
  },
});
