import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Wallet,
  LineChart,
  Banknote,
  ShieldCheck,
  Receipt,
  MessageCircle,
  BadgeCheck,
  Quote,
} from "lucide-react";
import { SiteLayout } from "@/components/site/Layout";

/**
 * /case-studies — proof page.
 *
 * Content is anonymised composites — swap names/figures in the arrays below.
 * Filter chips are pure React state (no backend). To add a study, append to
 * `studies` with a matching `categories` entry; chips auto-derive from them.
 */

type Category = "SaaS" | "SME" | "Fundraise" | "R&D Tax" | "FP&A" | "Compliance";

type Study = {
  id: string;
  tag: string;
  categories: Category[];
  icon: typeof Wallet;
  title: string;
  summary: string;
  stats: { value: string; label: string }[];
  quote: string;
  attribution: string;
  service: string;
};

const studies: Study[] = [
  {
    id: "agency-cashflow",
    tag: "SME · Cash Flow",
    categories: ["SME"],
    icon: Wallet,
    title: "Seeing round the corner on cash",
    summary:
      "A growing 12-person agency never knew if payroll would clear — late invoices, 60-day client terms, no visibility past the current balance. We set up a rolling 13-week cash flow forecast, automated invoicing and chasing, and delivered readable monthly management accounts.",
    stats: [
      { value: "58 → 31", label: "debtor days" },
      { value: "3 → 13 wks", label: "visible runway" },
      { value: "+4", label: "confident new hires" },
    ],
    quote:
      "I make hiring decisions on data now, not a gut feeling about the bank balance.",
    attribution: "Managing Director",
    service: "Monthly Retainer",
  },
  {
    id: "series-a-fpa",
    tag: "SaaS · FP&A",
    categories: ["SaaS", "FP&A"],
    icon: LineChart,
    title: "Building an FP&A function post-Series A",
    summary:
      "The board wanted monthly reporting the team couldn't produce — no budget-vs-actual, no churn cohorts, and a week of founder time lost to board prep each month. We stood up a board pack, a SaaS metrics dashboard, and a budgeting process, and now run the monthly close.",
    stats: [
      { value: "5 days → ½ day", label: "board prep" },
      { value: "<3%", label: "actual vs forecast" },
      { value: "112%", label: "net revenue retention" },
    ],
    quote:
      "Board meetings stopped being about 'where are the numbers' and started being about strategy.",
    attribution: "Founder",
    service: "Consulting & FP&A",
  },
  {
    id: "rd-tax",
    tag: "SaaS · R&D Tax",
    categories: ["SaaS", "R&D Tax"],
    icon: Banknote,
    title: "£52k of R&D relief they'd written off",
    summary:
      "A bootstrapped dev-tools team was building genuinely novel software but had never claimed R&D tax relief, assuming it wasn't for them. We assessed eligibility, scoped the qualifying work with the engineering lead, and filed a defensible claim with the technical narrative and cost breakdown.",
    stats: [
      { value: "£52,000", label: "relief recovered" },
      { value: "<3 wks", label: "claim filed" },
      { value: "+2", label: "engineers hired with it" },
    ],
    quote: "I'd written off R&D credits as not worth the hassle. The money was real.",
    attribution: "Technical Founder",
    service: "Annual Compliance",
  },
  {
    id: "compliance-rescue",
    tag: "SME · Compliance",
    categories: ["SME", "Compliance"],
    icon: ShieldCheck,
    title: "From HMRC dread to nothing to worry about",
    summary:
      "An e-commerce brand had fallen behind on VAT and filed late accounts two years running, racking up penalties and interest. We brought every filing up to date, corrected prior VAT errors, made representations to HMRC, and moved them onto a monthly retainer so nothing slips again.",
    stats: [
      { value: "2 yrs", label: "overdue filings cleared" },
      { value: "Reduced", label: "penalties after our reps" },
      { value: "~£6k/yr", label: "saved on VAT scheme" },
    ],
    quote:
      "I used to lie awake worrying about HMRC letters. Now I don't think about it at all.",
    attribution: "Owner",
    service: "Annual Compliance → Monthly Retainer",
  },
];

const CHIPS: ("All" | Category)[] = [
  "All",
  "SaaS",
  "SME",
  "Fundraise",
  "R&D Tax",
  "FP&A",
  "Compliance",
];

const HERO_STATS = [
  { value: "£800k+", label: "raised with Valentra-prepared data rooms" },
  { value: "£50k+", label: "R&D tax relief recovered for one client" },
  { value: "<3%", label: "forecast variance on managed FP&A" },
  { value: "30 days", label: "to investor-ready books" },
];

// JSON-LD ItemList of case studies (Article entries)
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  name: "Valentra Capital Case Studies",
  itemListElement: [
    {
      "@type": "Article",
      position: 1,
      headline: "From shoebox to seed round in 6 weeks",
      about: "SaaS · Fundraise",
    },
    ...studies.map((s, i) => ({
      "@type": "Article",
      position: i + 2,
      headline: s.title,
      about: s.tag,
    })),
  ],
};

export const Route = createFileRoute("/case-studies")({
  head: () => ({
    meta: [
      { title: "Case Studies — Valentra Capital" },
      {
        name: "description",
        content:
          "Real outcomes for SaaS founders and scaling SMEs — fundraises closed, runways extended, R&D tax recovered, and finance functions built.",
      },
      { property: "og:title", content: "Case Studies — Valentra Capital" },
      {
        property: "og:description",
        content:
          "Real outcomes for SaaS founders and scaling SMEs — fundraises closed, runways extended, R&D tax recovered, and finance functions built.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/case-studies" },
    ],
    links: [{ rel: "canonical", href: "/case-studies" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(jsonLd),
      },
    ],
  }),
  component: CaseStudiesPage,
});

function CaseStudiesPage() {
  const [active, setActive] = useState<"All" | Category>("All");

  const visible =
    active === "All" ? studies : studies.filter((s) => s.categories.includes(active));
  // "Fundraise" applies to the featured story only.
  const showFeatured = active === "All" || active === "SaaS" || active === "Fundraise";

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden px-6 pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_oklch(0.32_0.06_255/0.6),_transparent_60%)]" />
        <div className="mx-auto max-w-5xl text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">
            Case Studies
          </span>
          <h1 className="mt-6 font-serif text-5xl leading-tight text-white md:text-7xl">
            Proof, not promises.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-body/80">
            From messy spreadsheets to closed rounds — here's what changes when
            founders stop firefighting their finances.
          </p>

          {/* Stat strip */}
          <div className="mx-auto mt-14 grid max-w-4xl grid-cols-2 gap-8 md:grid-cols-4">
            {HERO_STATS.map((s) => (
              <div key={s.label} className="text-center">
                <div className="font-serif text-3xl text-gold md:text-4xl">
                  {s.value}
                </div>
                <div className="mt-2 text-xs leading-relaxed text-caption">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FILTER CHIPS */}
      <section className="px-6 pb-6">
        <div className="mx-auto flex max-w-7xl flex-wrap justify-center gap-3">
          {CHIPS.map((chip) => {
            const isActive = active === chip;
            return (
              <button
                key={chip}
                onClick={() => setActive(chip)}
                className={`rounded-full px-5 py-2 text-sm transition ${
                  isActive
                    ? "bg-gold text-primary-foreground"
                    : "border border-gold/40 text-body/90 hover:border-gold hover:text-gold"
                }`}
                aria-pressed={isActive}
              >
                {chip}
              </button>
            );
          })}
        </div>
      </section>

      {/* FEATURED CASE STUDY */}
      {showFeatured && (
        <section className="px-6 py-16">
          <div className="mx-auto max-w-7xl">
            <article className="relative overflow-hidden rounded-2xl border border-gold/20 border-l-4 border-l-gold bg-navy-elevated p-8 md:p-14">
              <span className="inline-flex items-center rounded-full border border-gold/40 px-3 py-1 text-xs uppercase tracking-[0.18em] text-gold">
                SaaS · Fundraise · Featured
              </span>
              <h2 className="mt-6 font-serif text-3xl text-white md:text-5xl">
                From shoebox to seed round in 6 weeks
              </h2>
              <p className="mt-6 max-w-3xl text-lg leading-relaxed text-body/85">
                The founder had early traction but ran the books out of a
                spreadsheet and a shoebox of receipts. With a seed round looming,
                investors wanted a data room, clean MRR, and a 3-year model — none
                of which existed. We cleaned up 14 months of bookkeeping, rebuilt
                the chart of accounts around SaaS metrics, and delivered an
                investor-ready data room with a 3-statement model and bottom-up
                forecast.
              </p>

              <div className="mt-10 grid gap-6 md:grid-cols-3">
                {[
                  { v: "6 weeks", l: "data room from scratch" },
                  { v: "£750k", l: "seed round closed" },
                  { v: "0", l: "model revisions in diligence" },
                ].map((s) => (
                  <div
                    key={s.l}
                    className="rounded-lg border border-border bg-background/40 p-6"
                  >
                    <div className="font-serif text-3xl text-gold">{s.v}</div>
                    <div className="mt-2 text-sm text-caption">{s.l}</div>
                  </div>
                ))}
              </div>

              <blockquote className="mt-10 flex gap-4 border-l-2 border-gold/60 pl-6">
                <Quote
                  className="h-6 w-6 shrink-0 text-gold"
                  aria-hidden
                />
                <div>
                  <p className="font-serif text-xl italic text-white/90 md:text-2xl">
                    "I went from dreading the finance questions to letting
                    Valentra take them. The model held up under diligence —
                    that's what got the round over the line."
                  </p>
                  <footer className="mt-3 text-sm text-caption">
                    — Founder & CEO
                  </footer>
                </div>
              </blockquote>

              <p className="mt-8 text-xs uppercase tracking-[0.18em] text-caption">
                Service used: Consulting & FP&A + Monthly Retainer
              </p>
            </article>
          </div>
        </section>
      )}

      {/* CASE STUDY GRID */}
      <section className="px-6 pb-20">
        <div className="mx-auto grid max-w-7xl gap-6 md:grid-cols-2">
          {visible.map((s) => {
            const Icon = s.icon;
            return (
              <article
                key={s.id}
                data-category={s.categories.join(",")}
                className="group flex flex-col rounded-2xl border border-border bg-navy-elevated p-8 transition hover:border-gold/60"
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-full border border-gold/40 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-gold">
                    {s.tag}
                  </span>
                  <Icon
                    className="h-6 w-6 text-gold/80 transition group-hover:text-gold"
                    aria-hidden
                  />
                </div>

                <h3 className="mt-6 font-serif text-2xl text-white md:text-3xl">
                  {s.title}
                </h3>
                <p className="mt-4 text-body/80">{s.summary}</p>

                <div className="mt-6 grid grid-cols-3 gap-3 border-y border-border py-5">
                  {s.stats.map((st) => (
                    <div key={st.label}>
                      <div className="font-serif text-lg text-gold md:text-xl">
                        {st.value}
                      </div>
                      <div className="mt-1 text-[11px] leading-snug text-caption">
                        {st.label}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="mt-6 font-serif text-base italic text-white/85">
                  "{s.quote}"
                </p>
                <p className="mt-2 text-xs text-caption">— {s.attribution}</p>

                <p className="mt-auto pt-6 text-xs uppercase tracking-[0.18em] text-caption">
                  Service used: {s.service}
                </p>
              </article>
            );
          })}
          {visible.length === 0 && !showFeatured && (
            <p className="col-span-full text-center text-caption">
              No case studies in this category yet.
            </p>
          )}
        </div>
      </section>

      {/* HOW WE WORK REASSURANCE STRIP */}
      <section className="border-y border-border bg-background px-6 py-10">
        <div className="mx-auto grid max-w-7xl gap-6 md:grid-cols-3">
          {[
            { icon: Receipt, text: "Fixed monthly fees, no surprise bills" },
            { icon: MessageCircle, text: "Real humans, fast replies on WhatsApp" },
            { icon: BadgeCheck, text: "ICO registered · HMRC AML supervised" },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-4">
              <Icon className="h-5 w-5 text-gold" aria-hidden />
              <span className="text-sm text-body/90">{text}</span>
            </div>
          ))}
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="relative overflow-hidden px-6 py-24">
        <div className="absolute inset-0 -z-10 bg-navy-elevated" />
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,_oklch(0.78_0.12_85/0.18),_transparent_60%)]" />
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-serif text-4xl text-white md:text-5xl">
            Your story could be next.
          </h2>
          <p className="mt-5 text-lg text-body/85">
            Book a free 15-minute clarity call. No sales pitch — walk away with
            at least one actionable insight.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link
              to="/contact"
              className="inline-flex items-center rounded-md bg-gold px-7 py-3.5 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft"
            >
              Book your clarity call
            </Link>
            <Link
              to="/services"
              className="inline-flex items-center rounded-md border border-gold/60 px-7 py-3.5 text-sm font-medium text-gold transition hover:bg-gold/10"
            >
              See our services
            </Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
