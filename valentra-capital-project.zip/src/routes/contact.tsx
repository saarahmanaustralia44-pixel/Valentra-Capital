import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { SiteLayout } from "@/components/site/Layout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

/**
 * /contact — clarity-call booking + fallback message form + FAQ.
 *
 * Sections:
 *  1. Hero
 *  2. Two-column: Calendly embed (LEFT) + contact details card (RIGHT)
 *  3. Fallback message form (posts to /api/contact — TODO wiring)
 *  4. FAQ accordion (edit `faqs` array to change entries)
 */

// ============ FAQ DATA ============
const faqs: { q: string; a: string }[] = [
  {
    q: "How quickly can you start?",
    a: "AML onboarding takes 2–5 days. Service begins immediately after that.",
  },
  {
    q: "Do I need to switch from my current accountant?",
    a: "No — we can run alongside, take over the bits that aren't working, or fully transition. Your call.",
  },
  {
    q: "What if I'm not VAT-registered yet?",
    a: "We'll register you when you cross the threshold (£90,000) and handle MTD compliance from day one.",
  },
  {
    q: "Is everything done online?",
    a: "Yes — Xero, QuickBooks, FreeAgent, Calendly, WhatsApp. Doncaster office available for in-person meetings on request.",
  },
];

// ============ FORM VALIDATION SCHEMA ============
const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Enter a valid email").max(255),
  company: z.string().trim().max(150).optional().or(z.literal("")),
  message: z
    .string()
    .trim()
    .min(200, "Please give us at least 200 characters of context")
    .max(2000, "Message must be under 2000 characters"),
  // Honeypot — must stay empty. Bots typically fill every field.
  website: z.string().max(0, "Spam detected").optional().or(z.literal("")),
});

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Book your clarity call · Valentra Capital" },
      {
        name: "description",
        content:
          "Book your free 15-minute clarity call with Valentra Capital. No sales pitch — walk away with at least one actionable insight.",
      },
      { property: "og:title", content: "Book your clarity call — Valentra Capital" },
      {
        property: "og:description",
        content: "Free 15-minute call. No sales pitch. One actionable insight, guaranteed.",
      },
    ],
    links: [{ rel: "canonical", href: "https://valentracapital.co.uk/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <SiteLayout>
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden px-6 pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="absolute inset-0 -z-10 hero-gradient" />
        <div className="mx-auto max-w-4xl text-center">
          <span className="text-xs uppercase tracking-[0.28em] text-gold">Contact</span>
          <h1 className="mt-6 font-serif text-5xl leading-[1.05] text-white md:text-7xl">
            Book your free 15-minute clarity call.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-body/80">
            No sales pitch. Walk away with at least one actionable insight.
          </p>
        </div>
      </section>

      {/* ============ TWO-COLUMN: CALENDLY + CONTACT DETAILS ============ */}
      <section className="bg-navy-elevated px-6 py-20 md:py-24">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1.4fr_1fr]">
          {/* LEFT — Calendly embed.
              TODO: Replace data-url below with your real Calendly link.
              The Calendly widget script is loaded inline; remove the script
              tag if you switch to a different booking provider. */}
          <div className="rounded-xl border border-border bg-[oklch(0.20_0.03_255)] p-2">
            <div
              className="calendly-inline-widget"
              data-url="https://calendly.com/valentracapital/clarity-call"
              style={{ minWidth: "320px", height: "600px" }}
              aria-label="Calendly booking widget"
            />
            <script
              async
              src="https://assets.calendly.com/assets/external/widget.js"
            ></script>
          </div>

          {/* RIGHT — Contact details */}
          <aside className="rounded-xl border border-gold/50 bg-[oklch(0.20_0.03_255)] p-8">
            <div className="text-xs uppercase tracking-[0.28em] text-gold">Direct channels</div>
            <h2 className="mt-3 font-serif text-2xl text-white">Reach us directly</h2>

            <ul className="mt-8 space-y-5 text-sm">
              <ContactRow label="Email">
                <a href="mailto:info@valentracapital.co.uk" className="text-body hover:text-gold">
                  info@valentracapital.co.uk
                </a>
              </ContactRow>
              <ContactRow label="Phone">
                <a href="tel:+447398909701" className="text-body hover:text-gold">
                  +44 7398 909701
                </a>
              </ContactRow>
              <ContactRow label="WhatsApp">
                <a
                  href="https://wa.me/447398909701"
                  target="_blank"
                  rel="noreferrer"
                  className="text-body hover:text-gold"
                >
                  +44 7398 909701
                </a>
              </ContactRow>
              <ContactRow label="Address">
                <span className="text-body/85">
                  Gresley House, Ten Pound Walk
                  <br />
                  Doncaster DN4 5HX
                </span>
              </ContactRow>
              <ContactRow label="Hours">
                <span className="text-body/85">Monday–Friday · 9am–6pm GMT</span>
              </ContactRow>
            </ul>

            <div className="mt-8 h-px gold-divider" />
            <p className="mt-6 text-xs leading-relaxed text-caption">
              Replies within one working day. Urgent enquiries — WhatsApp gets the fastest answer.
            </p>
          </aside>
        </div>
      </section>

      {/* ============ FALLBACK MESSAGE FORM ============ */}
      <section className="px-6 py-20 md:py-28">
        <div className="mx-auto max-w-3xl">
          <div className="text-center">
            <span className="text-xs uppercase tracking-[0.28em] text-gold">
              Prefer to write?
            </span>
            <h2 className="mt-4 font-serif text-3xl text-white md:text-4xl">
              Send us a message
            </h2>
            <p className="mt-4 text-body/75">
              Drop the details and we'll come back to you within one working day.
            </p>
          </div>

          <ContactForm />
        </div>
      </section>

      {/* ============ FAQ ============ */}
      <section className="bg-navy-elevated px-6 py-20 md:py-28">
        <div className="mx-auto max-w-3xl">
          <div className="text-center">
            <span className="text-xs uppercase tracking-[0.28em] text-gold">FAQ</span>
            <h2 className="mt-4 font-serif text-3xl text-white md:text-4xl">
              Common questions
            </h2>
          </div>

          <Accordion type="single" collapsible className="mt-10 space-y-3">
            {faqs.map((f, i) => (
              <AccordionItem
                key={f.q}
                value={`item-${i}`}
                className="rounded-xl border border-border bg-[oklch(0.20_0.03_255)] px-6 data-[state=open]:border-gold/50"
              >
                <AccordionTrigger className="text-left font-serif text-lg text-white hover:text-gold hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="text-base leading-relaxed text-body/80">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>
    </SiteLayout>
  );
}

/* ============ CONTACT ROW (label + value) ============ */
function ContactRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <li className="grid grid-cols-[100px_1fr] items-start gap-4">
      <span className="text-[11px] uppercase tracking-[0.22em] text-caption">{label}</span>
      <span>{children}</span>
    </li>
  );
}

/* ============ MESSAGE FORM ============
 * Client-side validated with zod. Posts to /api/contact.
 * TODO: wire /api/contact to Resend or Formspree.
 * Honeypot field `website` must remain empty — bots fill it, we drop the submission.
 */
function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErrors({});
    const fd = new FormData(e.currentTarget);
    const data = {
      name: String(fd.get("name") || ""),
      email: String(fd.get("email") || ""),
      company: String(fd.get("company") || ""),
      message: String(fd.get("message") || ""),
      website: String(fd.get("website") || ""), // honeypot
    };

    const parsed = contactSchema.safeParse(data);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        fieldErrors[issue.path[0] as string] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }

    // Silently drop honeypot hits — don't tell the bot it failed.
    if (parsed.data.website) {
      setStatus("sent");
      return;
    }

    setStatus("sending");
    try {
      // TODO: connect /api/contact handler to Resend or Formspree
      await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      setStatus("sent");
      (e.target as HTMLFormElement).reset();
    } catch {
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <div className="mt-12 rounded-xl border border-gold/40 bg-[oklch(0.20_0.03_255)] p-10 text-center">
        <h3 className="font-serif text-2xl text-gold">Message received.</h3>
        <p className="mt-3 text-body/80">
          We'll be in touch within one working day. Check your inbox (and spam folder, just in case).
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="mt-12 space-y-5" noValidate>
      {/* Honeypot — hidden from humans, visible to dumb bots.
          aria-hidden + tabIndex -1 keeps it out of keyboard / screen-reader flow. */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label>
          Website (leave blank)
          <input type="text" name="website" tabIndex={-1} autoComplete="off" />
        </label>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        <Field label="Name" name="name" error={errors.name} required />
        <Field label="Email" name="email" type="email" error={errors.email} required />
      </div>
      <Field label="Company" name="company" error={errors.company} />

      <div>
        <label
          htmlFor="message"
          className="text-xs uppercase tracking-[0.22em] text-caption"
        >
          What do you need help with? <span className="text-gold">*</span>
        </label>
        <textarea
          id="message"
          name="message"
          rows={6}
          minLength={200}
          maxLength={2000}
          required
          placeholder="Stage, monthly revenue, current setup, what's broken — minimum 200 characters."
          className="mt-2 w-full rounded-md border border-border bg-[oklch(0.20_0.03_255)] px-4 py-3 text-sm text-white placeholder:text-caption/70 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold/40"
        />
        {errors.message && <p className="mt-2 text-xs text-red-400">{errors.message}</p>}
      </div>

      <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-caption">
          By submitting you agree to our{" "}
          <a href="/privacy" className="text-gold hover:underline">
            privacy policy
          </a>
          .
        </p>
        <button
          type="submit"
          disabled={status === "sending"}
          className="inline-flex items-center rounded-md bg-gold px-8 py-3.5 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft disabled:opacity-60"
        >
          {status === "sending" ? "Sending…" : "Send message →"}
        </button>
      </div>

      {status === "error" && (
        <p className="text-sm text-red-400">
          Something went wrong sending the message. Email us directly at info@valentracapital.co.uk.
        </p>
      )}
    </form>
  );
}

/* ============ REUSABLE FIELD ============ */
function Field({
  label,
  name,
  type = "text",
  error,
  required,
}: {
  label: string;
  name: string;
  type?: string;
  error?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="text-xs uppercase tracking-[0.22em] text-caption">
        {label}
        {required && <span className="text-gold"> *</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        maxLength={255}
        className="mt-2 w-full rounded-md border border-border bg-[oklch(0.20_0.03_255)] px-4 py-3 text-sm text-white placeholder:text-caption/70 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold/40"
      />
      {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
    </div>
  );
}
