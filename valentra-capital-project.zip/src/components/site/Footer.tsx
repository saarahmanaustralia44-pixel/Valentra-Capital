import { Link } from "@tanstack/react-router";

// Footer — navy-section bg with thin gold divider on top.
// Three columns: company info, link list, contact channels.
// Bottom strip has copyright + ICO/HMRC AML reference.
export function Footer() {
  return (
    <footer className="relative border-t border-border bg-navy-elevated">
      <div className="absolute inset-x-0 top-0 h-px gold-divider" />
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-3">
        {/* Column 1 — company */}
        <div>
          <div className="font-serif text-xl text-white">Valentra Capital</div>
          <p className="mt-4 text-sm leading-relaxed text-caption">
            Valentra Capital Accounting and Consulting Limited
            <br />
            Gresley House, Ten Pound Walk
            <br />
            Doncaster DN4 5HX
          </p>
          <p className="mt-4 text-xs text-caption">
            Company No: 16829883
            <br />
            Registered in England and Wales
          </p>
        </div>

        {/* Column 2 — links */}
        <div className="md:justify-self-center">
          <div className="text-xs uppercase tracking-[0.2em] text-gold">Explore</div>
          <ul className="mt-4 grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
            {[
              { to: "/", label: "Home" },
              { to: "/services", label: "Services" },
              { to: "/tools", label: "Tools" },
              { to: "/about", label: "About" },
              { to: "/case-studies", label: "Case Studies" },
              { to: "/contact", label: "Contact" },
              { to: "/privacy", label: "Privacy Policy" },
              { to: "/cookies", label: "Cookies" },
            ].map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="text-body/90 hover:text-gold transition-colors">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Column 3 — contact */}
        <div className="md:justify-self-end">
          <div className="text-xs uppercase tracking-[0.2em] text-gold">Contact</div>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a href="mailto:info@valentracapital.co.uk" className="text-body hover:text-gold">
                info@valentracapital.co.uk
              </a>
            </li>
            <li>
              <a href="tel:+447398909701" className="text-body hover:text-gold">
                +44 7398 909701
              </a>
            </li>
            <li>
              <a
                href="https://wa.me/447398909701"
                target="_blank"
                rel="noreferrer"
                className="text-body hover:text-gold"
              >
                WhatsApp
              </a>
            </li>
            <li>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="inline-flex h-9 w-9 items-center justify-center rounded border border-gold/40 text-gold hover:bg-gold/10 transition"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden>
                  <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8h4.56v14H.22V8zm7.4 0h4.37v1.92h.06c.61-1.15 2.1-2.36 4.32-2.36 4.62 0 5.47 3.04 5.47 6.99V22h-4.56v-6.18c0-1.47-.03-3.36-2.05-3.36-2.05 0-2.36 1.6-2.36 3.25V22H7.62V8z" />
                </svg>
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom strip — legal + regulatory references */}
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-6 py-6 text-xs text-caption md:flex-row">
          <div>© {new Date().getFullYear()} Valentra Capital. All rights reserved.</div>
          <div className="text-[11px] tracking-wide text-caption/80">
            ICO Registered · HMRC AML MLR-262826 (pending)
          </div>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="hover:text-gold">Privacy Policy</Link>
            <Link to="/cookies" className="hover:text-gold">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
