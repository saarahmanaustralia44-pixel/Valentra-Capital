import type { ReactNode } from "react";
import { Nav } from "./Nav";
import { Footer } from "./Footer";

// Shared shell for all pages: sticky nav + content + footer.
export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-body">
      <Nav />
      <main>{children}</main>
      <Footer />
    </div>
  );
}
