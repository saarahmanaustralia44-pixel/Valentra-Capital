import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

// Top navigation – sticky, semi-transparent navy with blur backdrop.
// Edit the `links` array to change nav items. CTA on the right goes to /contact.
const links = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/tools", label: "Tools" },
  { to: "/about", label: "About" },
  { to: "/case-studies", label: "Case Studies" },
  { to: "/contact", label: "Contact" },
] as const;

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "backdrop-blur-md bg-[oklch(0.22_0.03_255/0.78)] border-b border-border"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:py-5">
        {/* Brand wordmark — swap for an <img src="..." /> logo when ready (target 40px tall) */}
        <Link to="/" className="flex items-center gap-3" aria-label="Valentra Capital logo">
          <span className="font-serif text-xl md:text-2xl tracking-wide text-white">
            Valentra <span className="text-gold">Capital</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="gold-underline text-sm text-body/90 hover:text-white transition-colors"
              activeProps={{ "data-active": "true", className: "text-white" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:block">
          <Link
            to="/contact"
            className="inline-flex items-center rounded-md bg-gold px-5 py-2.5 text-sm font-medium text-primary-foreground transition hover:bg-gold-soft"
          >
            Book a Call
          </Link>
        </div>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded border border-border text-white"
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          <span className="block h-px w-5 bg-white shadow-[0_-6px_0_white,0_6px_0_white]" />
        </button>
      </div>

      {/* Mobile full-screen overlay menu */}
      {open && (
        <div className="md:hidden fixed inset-0 top-[64px] z-40 bg-[oklch(0.22_0.03_255/0.98)] backdrop-blur">
          <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-10">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="font-serif text-2xl text-white hover:text-gold"
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-4 inline-flex w-fit items-center rounded-md bg-gold px-6 py-3 text-sm font-medium text-primary-foreground"
            >
              Book a Call
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
